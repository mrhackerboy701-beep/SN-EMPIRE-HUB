import * as React from 'react';
import { GlassCard } from './ui';

interface AdBannerProps {
  slotId?: string;
  className?: string;
}

export function AdBanner({ slotId, className = "" }: AdBannerProps) {
  // Common styling for an ad placeholder
  return (
    <div className={`w-full max-w-4xl mx-auto my-8 ${className}`}>
      <GlassCard className="py-4 px-2 border-dashed border-zinc-200 dark:border-zinc-800 text-center min-h-[100px] flex items-center justify-center bg-zinc-50/50 dark:bg-zinc-900/30">
        <div className="space-y-1">
          <div className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em] mb-2">Advertisement</div>
          {/* 
              USER: Replace this div with your actual Ad code (e.g., Google AdSense <ins> tag)
          */}
          <div className="text-sm text-zinc-500 italic">
            Your Ad Code Goes Here
          </div>
          {slotId && <div className="text-xs text-zinc-400">Slot: {slotId}</div>}
        </div>
      </GlassCard>
    </div>
  );
}
